erb integration_benchmark_test.go.erb > integration_benchmark_test.go
goimports -w integration_benchmark_test.go
